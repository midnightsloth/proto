# for i in range (len(rect)):
#   if self.rect.colliderect((rect[i])):
#     if i<2:
#       self.qual[0]=-self.qual[0]
#     else:
#       self.qual[1]=-self.qual[1]
