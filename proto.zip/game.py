from play import Player
class Game:
  def __init__(self):
    pl=Player(5,5,10,'a','d','w','s','q','e')
    