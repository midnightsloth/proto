class wall:
  def __init__(self,x,y,z):
    loc=[x,y,z]